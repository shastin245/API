const { Router } = require('express');

const router = new Router();

router.get('/test', (req, res) => {
    const data = {
        name: 'APIDAW',
        website: 'https://www.udb.edu.sv'
    };
    res.json(data);
});  

module.exports = router;




